function navbar(){
    return`
    <div id="navbar">
        <div id="frycry-logo">
            <img id="logo" src="./images/firstcrytag.jfif">

        </div>
        <div id="searchbar">
            <input id="input" type="text" placeholder="Search for a Category Brand or Product"/>
           <span> <img  id="search-icon"src="./images/searchimage.png"></span>

        </div>

        <div id="location">
            <img id="location-icon" src="./images/location.png">
            <div>Select location</div>

        </div>
        <div id="store">
            <div>Stores & Preschools</div>
        </div>
        <div id="support">
            <div>Support</div>
        </div>
        <div id="track">
            <div> Track Order</div>
        </div>
        <div id="parenting">
            <div>FirstCry Parenting </div>
        </div>
        <div id="login">
            <div>Login/Register</div>
        </div>
        <div id="Shortlist">
            <img id="shortlist-icon" src="./images/shortlist.png">
            <div>Shortlist</div>
        </div>
        <div id="cart">
            <img  id="cart-icon"src="./images/cart2.jpg">
            <div>Cart</div>
        </div>

    </div>
    <div id="navbar-2">
       <div id="categories">
         <div> ALL CATEGORIES</div>
         <div>BOY FASHION</div>
         <div>GIRL FASHION</div>
         <div>FOOTWEAR</div>
         <div>TOYS</div>
         <div>DIAPERING</div>
         <div>GEAR</div>
         <div>FEEDING</div>
         <div>BATH&SKIN</div>
         <div>NURSERY</div>
         <div>MOMS</div>
         <div>HEALTH & SAFETY</div>
         <div>BOUTIQUES</div>
         <div>Cart's</div>
       </div>
    </div>
    `
}

export default navbar;
